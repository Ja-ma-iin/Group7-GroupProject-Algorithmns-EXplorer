
package datastructures;

public class LinearQueue {

    private int[] queue;
    private int front;
    private int rear;
    private int capacity;

    // Constructor: creates a queue with fixed capacity.
    public LinearQueue(int capacity) {

        if (capacity <= 0) {
            throw new IllegalArgumentException(
                "Queue capacity must be greater than zero."
            );
        }

        this.capacity = capacity;
        queue = new int[capacity];

        front = 0;
        rear = -1;
    }

    // Enqueue: adds an element at the rear.
    // Time Complexity: O(1)
    public void enqueue(int value) {

        if (isFull()) {
            throw new IllegalStateException("Queue is full!");
        }

        queue[++rear] = value;
    }

    // Dequeue: removes and returns the front element.
    // Time Complexity: O(1)
    public int dequeue() {

        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty!");
        }

        int removed = queue[front];

        front++;

        return removed;
    }

    // Returns the front element without removing it.
    // Time Complexity: O(1)
    public int peek() {

        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty!");
        }

        return queue[front];
    }

    // Returns the number of elements.
    // Time Complexity: O(1)
    public int size() {
        return rear - front + 1;
    }

    // Checks whether the queue is empty.
    // Time Complexity: O(1)
    public boolean isEmpty() {
        return size() == 0;
    }

    // Checks whether the queue is full.
    // Time Complexity: O(1)
    public boolean isFull() {
        return rear == capacity - 1;
    }

    // Displays all queue elements.
    // Time Complexity: O(n)
    public void display() {

        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.print("Queue (Front to Rear): ");

        for (int i = front; i <= rear; i++) {
            System.out.print(queue[i] + " ");
        }

        System.out.println();
    }
}
